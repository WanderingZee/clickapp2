package com.pedalclick

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.pm.PackageManager
import android.media.midi.MidiDevice
import android.media.midi.MidiDeviceInfo
import android.media.midi.MidiManager
import android.media.midi.MidiReceiver
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.ParcelUuid
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject

/**
 * Hosts the click-track UI (assets/index.html) in a WebView and handles
 * Bluetooth LE MIDI + USB MIDI natively, forwarding messages to the page.
 */
@SuppressLint("MissingPermission")
class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var midi: MidiManager
    private var device: MidiDevice? = null
    private val main = Handler(Looper.getMainLooper())
    private val midiService = ParcelUuid.fromString("03B80E5A-EDE8-4B33-A751-6CE34EC4C700")
    private var scanning = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        midi = getSystemService(MIDI_SERVICE) as MidiManager
        web = WebView(this)
        setContentView(web)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.webViewClient = WebViewClient()
        web.addJavascriptInterface(Bridge(), "Android")
        web.loadUrl("file:///android_asset/index.html")
    }

    inner class Bridge {
        @JavascriptInterface
        fun connectMidi() { runOnUiThread { connect() } }
    }

    private fun js(code: String) = runOnUiThread { web.evaluateJavascript(code, null) }
    private fun status(s: String) = js("window.onNativeStatus(${JSONObject.quote(s)})")

    private fun needed(): Array<String> =
        if (Build.VERSION.SDK_INT >= 31)
            arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT)
        else arrayOf(Manifest.permission.ACCESS_FINE_LOCATION)

    private fun connect() {
        val missing = needed().filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) { requestPermissions(missing.toTypedArray(), 1); return }
        // 1) USB MIDI devices that are already plugged in
        val usb = midi.devices.firstOrNull { it.outputPortCount > 0 && it.type == MidiDeviceInfo.TYPE_USB }
        if (usb != null) {
            status("Opening USB MIDI device…")
            midi.openDevice(usb, { d -> if (d != null) attach(d) else status("Could not open the USB device.") }, main)
            return
        }
        // 2) Bluetooth LE MIDI
        val adapter = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
        if (adapter == null || !adapter.isEnabled) { status("Turn Bluetooth on, then tap Connect again."); return }
        val scanner = adapter.bluetoothLeScanner ?: run { status("Bluetooth scanner unavailable."); return }
        status("Scanning for Bluetooth MIDI devices… (switch the pedal on)")
        scanning = true
        scanner.startScan(
            listOf(ScanFilter.Builder().setServiceUuid(midiService).build()),
            ScanSettings.Builder().build(), scanCb
        )
        main.postDelayed({
            if (scanning) { stopScan(); status("No Bluetooth MIDI device found. Wake the pedal and tap Connect again.") }
        }, 15000)
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        if (res.isNotEmpty() && res.all { it == PackageManager.PERMISSION_GRANTED }) connect()
        else status("Bluetooth permission was denied. Allow it in the app settings.")
    }

    private fun stopScan() {
        scanning = false
        try {
            (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter.bluetoothLeScanner.stopScan(scanCb)
        } catch (_: Exception) {}
    }

    private val scanCb = object : ScanCallback() {
        override fun onScanResult(type: Int, r: ScanResult) {
            if (!scanning) return
            stopScan()
            val d: BluetoothDevice = r.device
            status("Connecting to ${d.name ?: d.address}…")
            midi.openBluetoothDevice(d, { dev ->
                if (dev != null) attach(dev) else status("Could not open the Bluetooth MIDI device.")
            }, main)
        }
        override fun onScanFailed(errorCode: Int) { status("Bluetooth scan failed (code $errorCode).") }
    }

    private fun attach(d: MidiDevice) {
        try { device?.close() } catch (_: Exception) {}
        device = d
        val port = d.openOutputPort(0)
        if (port == null) { status("This device has no MIDI output."); return }
        port.connect(receiver)
        val name = d.info.properties.getString(MidiDeviceInfo.PROPERTY_NAME) ?: "MIDI device"
        status("Connected: $name")
    }

    private val receiver = object : MidiReceiver() {
        override fun onSend(data: ByteArray, offset: Int, count: Int, timestamp: Long) {
            var i = offset
            val end = offset + count
            while (i < end) {
                val st = data[i].toInt() and 0xFF
                if (st < 0x80) { i++; continue }
                val k = st and 0xF0
                val len = if (k == 0xC0 || k == 0xD0) 2 else if (st >= 0xF0) 1 else 3
                if (i + len > end) break
                val d1 = if (len > 1) data[i + 1].toInt() and 0x7F else 0
                val d2 = if (len > 2) data[i + 2].toInt() and 0x7F else 0
                if (st < 0xF0) js("window.onNativeMidi($st,$d1,$d2)")
                i += len
            }
        }
    }

    override fun onDestroy() {
        try { device?.close() } catch (_: Exception) {}
        super.onDestroy()
    }
}
