# Pedal Click
Click track for Android with setlists, tempo changes by bar, custom click sounds and
M-Vave Chocolate Plus (Bluetooth or USB MIDI) pedal mapping.

Build: push to GitHub, open Actions > Build APK > latest run > download the PedalClick-apk artifact.
The UI lives in app/src/main/assets/index.html; MIDI is in MainActivity.kt.
